package nuc.ss.dao.user;

public class UserTest {
}
