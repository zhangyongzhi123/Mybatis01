package nuc.ss.dao.provider;

public class ProviderTest {
}
