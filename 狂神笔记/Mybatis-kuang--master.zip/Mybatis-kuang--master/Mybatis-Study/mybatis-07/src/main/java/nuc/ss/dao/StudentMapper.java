package nuc.ss.dao;

import nuc.ss.pojo.Student;

import java.util.List;

public interface StudentMapper {
}
